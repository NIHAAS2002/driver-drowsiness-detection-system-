# Driver-drownsiness-detector
**UI**
log in and register page 
![image](https://github.com/Karthik-PM/Driver-drownsiness-detector/assets/72903849/5c9ee3d4-806b-4056-9827-69f1a7438c50)
![image](https://github.com/Karthik-PM/Driver-drownsiness-detector/assets/72903849/53288f0c-27b3-45af-b6a5-461003d99c7e)

detection board 
![image](https://github.com/Karthik-PM/Driver-drownsiness-detector/assets/72903849/e08fba68-a15d-4939-b873-6196e883b309)
![image](https://github.com/Karthik-PM/Driver-drownsiness-detector/assets/72903849/88282d0b-9f91-42b6-9fb6-f38e7613ee42)

analytics dashboard
![image](https://github.com/Karthik-PM/Driver-drownsiness-detector/assets/72903849/952a2ea1-b71a-4996-a49a-c25e7f72118a)
